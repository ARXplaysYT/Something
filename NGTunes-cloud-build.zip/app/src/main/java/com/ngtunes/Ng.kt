package com.ngtunes

import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Song(val id: String, val title: String, val url: String? = null)

/** All Newgrounds scraping lives here. If the site layout changes, only this file needs fixing. */
object Ng {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.connectTimeout = 15000
        c.readTimeout = 25000
        return c
    }

    private fun getText(url: String): String = open(url).inputStream.bufferedReader().use { it.readText() }

    fun stream(url: String): InputStream = open(url).inputStream

    /** Featured songs when query is blank, otherwise a search. */
    fun list(query: String): List<Song> {
        val url = if (query.isBlank()) "https://www.newgrounds.com/audio/featured"
        else "https://www.newgrounds.com/search/conduct/audio?terms=" + URLEncoder.encode(query, "UTF-8")
        val html = getText(url)
        val anchor = Regex(
            """<a[^>]+href="https?://www\.newgrounds\.com/audio/listen/(\d+)"([^>]*)>(.*?)</a>""",
            RegexOption.DOT_MATCHES_ALL
        )
        val best = LinkedHashMap<String, String>()
        for (m in anchor.findAll(html)) {
            val id = m.groupValues[1]
            val inner = m.groupValues[3].replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()
            val attr = Regex("""title="([^"]+)"""").find(m.groupValues[2])?.groupValues?.get(1)?.trim().orEmpty()
            val t = decode(if (inner.isNotBlank()) inner else attr)
            if (id !in best || t.length > best[id]!!.length) best[id] = t
        }
        return best.map { (id, t) -> Song(id, t.ifBlank { "Song #$id" }) }
    }

    /** Returns the direct audio file URL for a song page. */
    fun resolve(id: String): String {
        val html = getText("https://www.newgrounds.com/audio/listen/$id")
        val m = Regex("""https:(?:\\/|/){2}audio\.ngfiles\.com[^"'\s<>]+""").find(html)
            ?: error("Couldn't find the audio file for this song")
        return m.value.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&")
    }

    private fun decode(s: String) = s.replace("&amp;", "&").replace("&#039;", "'")
        .replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">")
}
