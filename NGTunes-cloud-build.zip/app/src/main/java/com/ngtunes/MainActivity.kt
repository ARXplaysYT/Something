package com.ngtunes

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
    override fun onDestroy() { Player.stop(); super.onDestroy() }
}

sealed interface Screen {
    object Browse : Screen
    data class Jukebox(val song: Song) : Screen
    data class Trim(val song: Song, val file: File, val back: Screen) : Screen
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Browse) }
    var query by remember { mutableStateOf("") }
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var playingId by remember { mutableStateOf<String?>(null) }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()

    fun search() {
        scope.launch {
            busy = true
            try {
                songs = withContext(Dispatchers.IO) { Ng.list(query) }
                if (songs.isEmpty()) toast("No songs found")
            } catch (e: Exception) { toast("Failed: ${e.message}") }
            busy = false
        }
    }

    fun stopAll() { Player.stop(); playingId = null }

    fun startPlay(song: Song, onDone: () -> Unit = {}) {
        scope.launch {
            try {
                val url = song.url ?: withContext(Dispatchers.IO) { Ng.resolve(song.id) }
                playingId = song.id
                Player.play(url) { playingId = null; onDone() }
            } catch (e: Exception) {
                toast("Failed: ${e.message}")
                playingId = null
                onDone()
            }
        }
    }

    fun togglePlay(song: Song) {
        if (playingId == song.id) stopAll() else startPlay(song)
    }

    fun playChain(list: List<Song>, i: Int) {
        if (i in list.indices) startPlay(list[i]) { playChain(list, i + 1) }
    }

    fun download(song: Song) {
        scope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { saveToMusic(ctx, song) }
                toast("Saved to Music/Newgrounds")
            } catch (e: Exception) { toast("Failed: ${e.message}") }
            busy = false
        }
    }

    fun ringtone(song: Song, back: Screen) {
        scope.launch {
            busy = true
            try {
                stopAll()
                val f = withContext(Dispatchers.IO) { fetchToCache(ctx, song) }
                screen = Screen.Trim(song, f, back)
            } catch (e: Exception) { toast("Failed: ${e.message}") }
            busy = false
        }
    }

    LaunchedEffect(Unit) { search() }

    BackHandler(enabled = screen !is Screen.Browse) {
        stopAll()
        screen = (screen as? Screen.Trim)?.back ?: Screen.Browse
    }

    when (val s = screen) {
        is Screen.Trim -> TrimScreen(
            song = s.song, file = s.file,
            onBack = { screen = s.back },
            onSave = { startMs, endMs ->
                if (!Settings.System.canWrite(ctx)) {
                    toast("Allow \"Modify system settings\" for NG Tunes, then press the button again")
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } else scope.launch {
                    try {
                        withContext(Dispatchers.IO) { setAsRingtone(ctx, s.song, s.file, startMs, endMs) }
                        toast("Ringtone set!")
                        screen = s.back
                    } catch (e: Exception) { toast("Failed: ${e.message}") }
                }
            }
        )

        is Screen.Jukebox -> JukeboxScreen(
            song = s.song, playingId = playingId, busy = busy,
            onBack = { stopAll(); screen = Screen.Browse },
            onToggle = { togglePlay(it) },
            onDownload = { download(it) },
            onRingtone = { ringtone(it, s) },
            onPlayAll = { playChain(it, 0) },
            onStop = { stopAll() }
        )

        Screen.Browse -> Column(Modifier.fillMaxSize().padding(12.dp)) {
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("Search Newgrounds songs") },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { search() }) { Text("Go") }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp)) {
                items(songs, key = { it.id }) { song ->
                    SongCard(
                        song = song, playing = playingId == song.id, busy = busy,
                        onPlay = { togglePlay(song) },
                        onDownload = { download(song) },
                        onRingtone = { ringtone(song, Screen.Browse) },
                        onJukebox = { stopAll(); screen = Screen.Jukebox(song) }
                    )
                }
            }
        }
    }
}

@Composable
fun SongCard(
    song: Song, playing: Boolean, busy: Boolean,
    onPlay: () -> Unit, onDownload: () -> Unit, onRingtone: () -> Unit,
    onJukebox: (() -> Unit)? = null,
    title: String = song.title
) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Row {
                TextButton(onClick = onPlay) { Text(if (playing) "■ Stop" else "▶ Play") }
                TextButton(enabled = !busy, onClick = onDownload) { Text("⬇ Download") }
            }
            Row {
                TextButton(enabled = !busy, onClick = onRingtone) { Text("🔔 Ringtone") }
                if (onJukebox != null) TextButton(onClick = onJukebox) { Text("🎛 Jukebox") }
            }
        }
    }
}

@Composable
fun JukeboxScreen(
    song: Song, playingId: String?, busy: Boolean,
    onBack: () -> Unit,
    onToggle: (Song) -> Unit, onDownload: (Song) -> Unit, onRingtone: (Song) -> Unit,
    onPlayAll: (List<Song>) -> Unit, onStop: () -> Unit
) {
    val ctx = LocalContext.current
    var remixes by remember { mutableStateOf<List<Remix>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(song.id) {
        try { remixes = withContext(Dispatchers.IO) { Sfh.remixesFor(ctx, song.id) } }
        catch (e: Exception) { error = e.message ?: "Couldn't load the remix list" }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Spacer(Modifier.height(24.dp))
        TextButton(onClick = onBack) { Text("← Back") }
        Text("Jukebox", style = MaterialTheme.typography.headlineSmall)
        Text(song.title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        val list = remixes
        when {
            error != null -> Text("Couldn't load remixes: $error")
            list == null -> {
                Text("Loading the Song File Hub remix list (first time only, can take a bit)…")
                LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            }
            list.isEmpty() -> Text("No remixes found on Song File Hub for this song.")
            else -> {
                val remixSongs = list.map { Song(it.id, it.name, it.url) }
                val queue = listOf(song) + remixSongs
                Text("${list.size} remix${if (list.size == 1) "" else "es"} found")
                Row {
                    Button(onClick = { onPlayAll(queue) }) { Text("▶ Play all") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = onStop) { Text("■ Stop") }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp)) {
                    item(key = "original") {
                        SongCard(
                            song = song, playing = playingId == song.id, busy = busy,
                            onPlay = { onToggle(song) }, onDownload = { onDownload(song) },
                            onRingtone = { onRingtone(song) },
                            title = "Original: ${song.title}"
                        )
                    }
                    items(remixSongs, key = { it.id }) { r ->
                        SongCard(
                            song = r, playing = playingId == r.id, busy = busy,
                            onPlay = { onToggle(r) }, onDownload = { onDownload(r) },
                            onRingtone = { onRingtone(r) }
                        )
                    }
                }
            }
        }
    }
}

private fun fmt(sec: Float): String {
    val t = sec.toInt()
    return "%d:%02d".format(t / 60, t % 60)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrimScreen(song: Song, file: File, onBack: () -> Unit, onSave: (Long, Long) -> Unit) {
    val canTrim = remember { isMp3(file) }
    val durSec = remember {
        val r = MediaMetadataRetriever()
        r.setDataSource(file.path)
        val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 30000L
        r.release()
        ms / 1000f
    }
    var range by remember { mutableStateOf(0f..(if (canTrim) minOf(30f, durSec) else durSec)) }
    var playing by remember { mutableStateOf(false) }
    val mp = remember { MediaPlayer().apply { setDataSource(file.path); prepare() } }
    DisposableEffect(Unit) { onDispose { mp.release() } }

    LaunchedEffect(playing) {
        if (playing) {
            mp.seekTo((range.start * 1000).toInt())
            mp.start()
            while (playing && mp.isPlaying && mp.currentPosition < range.endInclusive * 1000) delay(50)
            if (mp.isPlaying) mp.pause()
            playing = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("Edit ringtone", style = MaterialTheme.typography.headlineSmall)
        Text(song.title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(32.dp))
        if (canTrim) {
            RangeSlider(
                value = range,
                onValueChange = { if (!playing) range = it },
                valueRange = 0f..durSec
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Start ${fmt(range.start)}")
                Text("Length ${fmt(range.endInclusive - range.start)}")
                Text("End ${fmt(range.endInclusive)}")
            }
        } else {
            Text("This file is an OGG, which can't be trimmed here. The whole song (${fmt(durSec)}) will be used.")
        }
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = { playing = !playing }, modifier = Modifier.fillMaxWidth()) {
            Text(if (playing) "■ Stop preview" else "▶ Preview")
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                mp.pause(); playing = false
                onSave((range.start * 1000).toLong(), (range.endInclusive * 1000).toLong())
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("🔔 Set as ringtone") }
        TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
    }
}
