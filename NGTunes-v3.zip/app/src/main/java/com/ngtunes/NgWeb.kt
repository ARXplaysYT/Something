package com.ngtunes

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import kotlin.coroutines.resume

/**
 * Newgrounds blocks plain HTTP clients (HTTP 403), so pages are loaded in a real WebView
 * (a normal Chrome engine) and the finished page's HTML is read back out of it.
 */
object NgWeb {
    @Volatile var ua: String =
        "Mozilla/5.0 (Linux; Android 11; vivo Y21) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private lateinit var view: WebView
    @Volatile private var loaded = false

    @SuppressLint("SetJavaScriptEnabled")
    fun configure(w: WebView) {
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = true
        val clean = w.settings.userAgentString.replace("; wv", "").replace(" Version/4.0", "")
        w.settings.userAgentString = clean
        ua = clean
        CookieManager.getInstance().setAcceptCookie(true)
    }

    /** The invisible helper WebView used to fetch pages. */
    fun createHidden(ctx: Context): WebView {
        val w = WebView(ctx)
        configure(w)
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { loaded = true }
        }
        view = w
        return w
    }

    /** A normal visible WebView for browsing the site. */
    fun createVisible(ctx: Context): WebView {
        val w = WebView(ctx)
        configure(w)
        return w
    }

    /** Loads [url] and returns the page HTML once it contains [mustContain] (waits through any Cloudflare check). */
    suspend fun html(url: String, mustContain: String, timeoutMs: Long = 25000): String =
        withContext(Dispatchers.Main) {
            loaded = false
            view.loadUrl(url)
            val start = System.currentTimeMillis()
            var last = ""
            while (System.currentTimeMillis() - start < timeoutMs) {
                delay(600)
                if (!loaded) continue
                last = readHtml()
                if (last.contains(mustContain)) return@withContext last
            }
            error("Timed out waiting for the page (title: \"${view.title}\", ${last.length} characters)")
        }

    private suspend fun readHtml(): String = suspendCancellableCoroutine { c ->
        view.evaluateJavascript("document.documentElement.outerHTML") { raw ->
            val s = try { JSONTokener(raw ?: "").nextValue() as? String ?: "" } catch (e: Exception) { "" }
            c.resume(s)
        }
    }
}
