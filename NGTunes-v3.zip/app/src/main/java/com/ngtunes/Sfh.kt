package com.ngtunes

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import java.io.File

data class Remix(val id: String, val name: String, val artist: String, val url: String)

/**
 * Song File Hub remix lookup. Uses the community-maintained copy of the Song File Hub index
 * (the same one the Geometry Dash "Jukebox" mod uses). Each entry lists the Newgrounds song IDs
 * it is a remix/alt version of, plus a direct download URL.
 */
object Sfh {
    private const val INDEX_URL =
        "https://raw.githubusercontent.com/FlafyDev/auto-nong-indexes/v2/sfh-index.min.json"
    private const val MAX_AGE_MS = 24L * 3600 * 1000

    private var map: Map<Long, List<Remix>>? = null

    fun remixesFor(ctx: Context, ngId: String): List<Remix> {
        val id = ngId.toLongOrNull() ?: return emptyList()
        return load(ctx)[id].orEmpty()
    }

    @Synchronized
    private fun load(ctx: Context): Map<Long, List<Remix>> {
        map?.let { return it }
        val f = File(ctx.cacheDir, "sfh-index.json")
        val stale = !f.exists() || System.currentTimeMillis() - f.lastModified() > MAX_AGE_MS
        if (stale) {
            try {
                val tmp = File(f.path + ".tmp")
                Ng.stream(INDEX_URL).use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                tmp.renameTo(f)
            } catch (e: Exception) {
                if (!f.exists()) throw e   // offline but have an old copy -> use it
            }
        }
        val out = HashMap<Long, MutableList<Remix>>()
        JsonReader(f.reader().buffered()).use { r ->
            r.beginObject()
            while (r.hasNext()) {
                if (r.nextName() == "nongs") {
                    r.beginObject()
                    while (r.hasNext()) {
                        if (r.nextName() == "hosted") readHosted(r, out) else r.skipValue()
                    }
                    r.endObject()
                } else r.skipValue()
            }
            r.endObject()
        }
        out.values.forEach { l -> l.sortBy { it.name.lowercase() } }
        map = out
        return out
    }

    private fun JsonReader.str(): String =
        if (peek() == JsonToken.NULL) { nextNull(); "" } else nextString()

    private fun readHosted(r: JsonReader, out: HashMap<Long, MutableList<Remix>>) {
        r.beginObject()
        while (r.hasNext()) {
            val id = r.nextName()
            var name = ""; var artist = ""; var url = ""
            val songs = ArrayList<Long>()
            r.beginObject()
            while (r.hasNext()) {
                when (r.nextName()) {
                    "name" -> name = r.str()
                    "artist" -> artist = r.str()
                    "url" -> url = r.str()
                    "songs" -> {
                        r.beginArray()
                        while (r.hasNext()) songs.add(r.nextLong())
                        r.endArray()
                    }
                    else -> r.skipValue()
                }
            }
            r.endObject()
            if (url.isNotBlank()) {
                val title = if (artist.isBlank()) name else "$name — $artist"
                for (s in songs) if (s > 0) out.getOrPut(s) { mutableListOf() }.add(Remix(id, title, artist, url))
            }
        }
        r.endObject()
    }
}
