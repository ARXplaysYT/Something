package com.ngtunes

import android.webkit.CookieManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Song(val id: String, val title: String, val url: String? = null)

/** All Newgrounds scraping lives here. If the site layout changes, only this file needs fixing. */
object Ng {
    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", NgWeb.ua)
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        if (url.contains("ngfiles.com")) {
            c.setRequestProperty("Referer", "https://www.newgrounds.com/")
            CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
        }
        c.connectTimeout = 15000
        c.readTimeout = 30000
        return c
    }

    /** Plain file download (audio files, remix index). */
    fun stream(url: String): InputStream {
        val c = open(url)
        val code = c.responseCode
        if (code !in 200..299) throw IllegalStateException("Download failed: HTTP $code")
        return c.inputStream
    }

    private fun clean(s: String) = s.replace(Regex("<[^>]+>"), " ")
        .replace("&amp;", "&").replace("&#039;", "'").replace("&#39;", "'")
        .replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">")
        .replace(Regex("\\s+"), " ").trim()

    private fun titleFrom(window: String): String {
        Regex("""<h4[^>]*>(.*?)</h4>""", RegexOption.DOT_MATCHES_ALL).find(window)
            ?.let { clean(it.groupValues[1]) }?.takeIf { it.isNotBlank() }?.let { return it }
        Regex("""title="([^"]+)"""").find(window)
            ?.let { clean(it.groupValues[1]) }?.takeIf { it.isNotBlank() }?.let { return it }
        return ""
    }

    private fun parseList(html: String): List<Song> {
        // Works whether links are written as https://..., //www..., or /audio/listen/ID
        val matches = Regex("""/audio/listen/(\d+)""").findAll(html).toList()
        val best = LinkedHashMap<String, String>()
        for ((i, m) in matches.withIndex()) {
            val id = m.groupValues[1]
            val start = m.range.first
            val end = minOf(html.length, start + 900, matches.getOrNull(i + 1)?.range?.first ?: html.length)
            val t = titleFrom(html.substring(start, end))
            if (id !in best || (best[id].isNullOrBlank() && t.isNotBlank())) best[id] = t
        }
        return best.map { (id, t) -> Song(id, t.ifBlank { "Song #$id" }) }
    }

    /** Featured songs when query is blank, otherwise a search. */
    suspend fun list(query: String): List<Song> {
        val urls = if (query.isBlank())
            listOf("https://www.newgrounds.com/audio/featured", "https://www.newgrounds.com/audio")
        else listOf("https://www.newgrounds.com/search/conduct/audio?terms=" + URLEncoder.encode(query, "UTF-8"))
        var error: Exception? = null
        for (u in urls) {
            try {
                val html = NgWeb.html(u, "/audio/listen/")
                val songs = withContext(Dispatchers.Default) { parseList(html) }
                if (songs.isNotEmpty()) return songs
            } catch (e: Exception) { error = e }
        }
        throw error ?: IllegalStateException("No songs found")
    }

    /** Returns the direct audio file URL for a song page. */
    suspend fun resolve(id: String): String {
        val html = NgWeb.html("https://www.newgrounds.com/audio/listen/$id", "audio.ngfiles.com")
        val found = Regex("""https:(?:\\/|/){2}[\w.-]*ngfiles\.com(?:\\/|/)[^"'\s<>]+""")
            .findAll(html)
            .map { it.value.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&").trimEnd('\\') }
            .toList()
        return found.firstOrNull { it.contains("audio.ngfiles") }
            ?: found.firstOrNull { it.contains(".mp3") }
            ?: error("Couldn't find the audio file for this song")
    }
}
