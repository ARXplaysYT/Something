package com.ngtunes

import android.content.ContentValues
import android.content.Context
import android.media.MediaExtractor
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer

object Player {
    private var mp: MediaPlayer? = null
    /** onDone fires when the song ends or fails (not when you call stop()). */
    fun play(path: String, onDone: () -> Unit) {
        stop()
        mp = MediaPlayer().apply {
            setDataSource(path)
            setOnPreparedListener { it.start() }
            setOnCompletionListener { onDone() }
            setOnErrorListener { _, _, _ -> onDone(); true }
            prepareAsync()
        }
    }
    fun stop() { mp?.release(); mp = null }
}

private fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().take(80).ifBlank { "song" }

/** True for MP3 (ID3 tag or frame sync). Remixes on Song File Hub can also be OGG. */
fun isMp3(f: File): Boolean = f.inputStream().use {
    val b = ByteArray(3)
    if (it.read(b) < 3) return@use false
    val id3 = b[0] == 'I'.code.toByte() && b[1] == 'D'.code.toByte() && b[2] == '3'.code.toByte()
    val sync = (b[0].toInt() and 0xFF) == 0xFF && (b[1].toInt() and 0xE0) == 0xE0
    id3 || sync
}
private fun ext(f: File) = if (isMp3(f)) "mp3" else "ogg"
private fun mime(f: File) = if (isMp3(f)) "audio/mpeg" else "audio/ogg"

/** Downloads the song to the cache folder (once) and returns the file. */
suspend fun fetchToCache(ctx: Context, song: Song): File {
    val f = File(ctx.cacheDir, "${song.id}.audio")
    if (!f.exists() || f.length() == 0L) {
        val url = song.url ?: Ng.resolve(song.id)
        withContext(Dispatchers.IO) {
            val tmp = File(f.path + ".tmp")
            Ng.stream(url).use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            tmp.renameTo(f)
        }
    }
    return f
}

/** Saves the full song to Music/Newgrounds. */
suspend fun saveToMusic(ctx: Context, song: Song) {
    val src = fetchToCache(ctx, song)
    withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(song.title) + "." + ext(src))
            put(MediaStore.MediaColumns.MIME_TYPE, mime(src))
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Newgrounds")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Couldn't create the file")
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
    }
}

/** Copies whole MP3 frames between startMs and endMs. No re-encoding, so it's instant and lossless. */
fun trimMp3(src: File, startMs: Long, endMs: Long, out: OutputStream) {
    val ex = MediaExtractor()
    try {
        ex.setDataSource(src.absolutePath)
        ex.selectTrack(0)
        ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        val buf = ByteBuffer.allocate(1 shl 16)
        while (true) {
            buf.clear()
            val n = ex.readSampleData(buf, 0)
            if (n < 0 || ex.sampleTime > endMs * 1000) break
            out.write(buf.array(), 0, n)
            ex.advance()
        }
    } finally { ex.release() }
}

/** Trims (MP3 only), saves to Ringtones, and sets it as the default phone ringtone. */
fun setAsRingtone(ctx: Context, song: Song, src: File, startMs: Long, endMs: Long) {
    val mp3 = isMp3(src)
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(song.title) + " (ringtone)." + ext(src))
        put(MediaStore.MediaColumns.MIME_TYPE, mime(src))
        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES)
        put(MediaStore.Audio.Media.TITLE, song.title)
        put(MediaStore.Audio.Media.IS_RINGTONE, true)
        put(MediaStore.Audio.Media.IS_MUSIC, false)
    }
    val uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
        ?: error("Couldn't create the ringtone file")
    ctx.contentResolver.openOutputStream(uri)!!.use { o ->
        if (mp3) trimMp3(src, startMs, endMs, o) else src.inputStream().use { it.copyTo(o) }
    }
    RingtoneManager.setActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_RINGTONE, uri)
}
