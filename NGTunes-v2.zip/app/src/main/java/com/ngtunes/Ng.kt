package com.ngtunes

import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Song(val id: String, val title: String, val url: String? = null)

/** All Newgrounds scraping lives here. If the site layout changes, only this file needs fixing. */
object Ng {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 11; vivo Y21) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        c.connectTimeout = 15000
        c.readTimeout = 25000
        return c
    }

    private fun getText(url: String): String {
        val c = open(url)
        val code = c.responseCode
        if (code !in 200..299) throw IllegalStateException("Newgrounds answered with HTTP $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun stream(url: String): InputStream {
        val c = open(url)
        val code = c.responseCode
        if (code !in 200..299) throw IllegalStateException("Download failed: HTTP $code")
        return c.inputStream
    }

    private fun clean(s: String) = s.replace(Regex("<[^>]+>"), " ")
        .replace("&amp;", "&").replace("&#039;", "'").replace("&#39;", "'")
        .replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">")
        .replace(Regex("\\s+"), " ").trim()

    private fun titleFrom(window: String): String {
        Regex("""<h4[^>]*>(.*?)</h4>""", RegexOption.DOT_MATCHES_ALL).find(window)
            ?.let { clean(it.groupValues[1]) }?.takeIf { it.isNotBlank() }?.let { return it }
        Regex("""title="([^"]+)"""").find(window)
            ?.let { clean(it.groupValues[1]) }?.takeIf { it.isNotBlank() }?.let { return it }
        return ""
    }

    /** Featured songs when query is blank, otherwise a search. */
    fun list(query: String): List<Song> {
        val url = if (query.isBlank()) "https://www.newgrounds.com/audio/featured"
        else "https://www.newgrounds.com/search/conduct/audio?terms=" + URLEncoder.encode(query, "UTF-8")
        val html = getText(url)

        // Works whether links are written as https://..., //www..., or /audio/listen/ID
        val matches = Regex("""/audio/listen/(\d+)""").findAll(html).toList()
        val best = LinkedHashMap<String, String>()
        for ((i, m) in matches.withIndex()) {
            val id = m.groupValues[1]
            val start = m.range.first
            val end = minOf(html.length, start + 900, matches.getOrNull(i + 1)?.range?.first ?: html.length)
            val t = titleFrom(html.substring(start, end))
            if (id !in best || (best[id].isNullOrBlank() && t.isNotBlank())) best[id] = t
        }
        if (best.isEmpty()) {
            throw IllegalStateException(
                "No songs found in the page (${html.length} characters). It starts with: " +
                    html.take(150).replace(Regex("\\s+"), " ")
            )
        }
        return best.map { (id, t) -> Song(id, t.ifBlank { "Song #$id" }) }
    }

    /** Returns the direct audio file URL for a song page. */
    fun resolve(id: String): String {
        val html = getText("https://www.newgrounds.com/audio/listen/$id")
        val found = Regex("""https:(?:\\/|/){2}[\w.-]*ngfiles\.com(?:\\/|/)[^"'\s<>]+""")
            .findAll(html)
            .map { it.value.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&").trimEnd('\\') }
            .toList()
        return found.firstOrNull { it.contains("audio.ngfiles") }
            ?: found.firstOrNull { it.contains(".mp3") }
            ?: error("Couldn't find the audio file for this song (page was ${html.length} characters)")
    }
}
